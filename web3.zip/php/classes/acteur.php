<?php
Class Acteur {
    private string $nom;
    private string $photo;

    public function __construct($nom_act,$nom_photo) {
        $nom = $nom_act;
        $photo = $nom_photo;
    }
    
}

?>