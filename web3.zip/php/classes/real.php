<?php
Class Real {
    private string $nom;
    private string $photo;

    public function __construct($nom_real,$nom_photo) {
        $nom = $nom_real;
        $photo = $nom_photo;
    }
}

?>