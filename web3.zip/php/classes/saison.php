<?php
class Saison {
    public string $titre;
    public string $titre_serie;
    public string $affiche;
    public string $descr;
    public int $num_saison;
    


    
    
}

?>