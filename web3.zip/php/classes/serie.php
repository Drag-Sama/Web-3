<?php
class Serie {
    public string $titre;
    public string $tag;
    public string $affiche;
    



}

?>