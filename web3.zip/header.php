<a class="header-titre">
            <div class="titre">Tv Show</div>
        <form class="recherche" action="homepage.php?text=$_GET['text']" method="get">
            <input type="text" name="text" class="search-input" placeholder="Rechercher une serie..">
            <button type="submit" class="btn btn-primary">Click</button>
        </form>
    </header>